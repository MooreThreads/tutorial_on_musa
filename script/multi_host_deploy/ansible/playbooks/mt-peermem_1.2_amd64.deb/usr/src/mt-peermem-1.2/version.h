/*
 * Copyright (c) 2022 Moore Threads Technologies. All rights reserved.
 */

#define Version 1.2
#define MTGPU_VERSION_STRING "1.0"
