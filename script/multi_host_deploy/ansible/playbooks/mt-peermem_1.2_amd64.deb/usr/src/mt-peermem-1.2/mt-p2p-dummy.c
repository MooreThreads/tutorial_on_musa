/*
 * Copyright (c) 2023, Moore Threads Inc. All rights reserved.
 *
 */

/*
 * Warning: this kernel module is only needed at compile time.
 *
 * Long story is that this module is here only to produce the correct
 * module versions related to the very kernel where the other module (the
 * interesting one) is going to be compiled.  In other words, this module
 * produce the same symbol versions as the real MTGPU kernel-mode driver.
 *
 * Downside: the function signatures must be kept up-to-date.
 */

#include <linux/version.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/types.h>
#include <linux/delay.h>
#include <linux/compiler.h>
#include <linux/string.h>
#include <linux/uaccess.h>
#include <linux/fs.h>
#include <linux/list.h>
#include <linux/mm.h>
#include <linux/io.h>

#include "mt-p2p.h"
#include "ib_peer_mem.h"

MODULE_AUTHOR("Moore Threads GPU Cloud Computing");
MODULE_DESCRIPTION("Moore Threads GPU direct memory plug-in");
MODULE_LICENSE("Dual MIT/GPL");
MODULE_VERSION("0.1");

int mtgpu_p2p_get_pages(uint64_t virtual_address, uint64_t length,
                        struct mtgpu_p2p_page_table **page_table)
{
    return -EINVAL;
}
EXPORT_SYMBOL(mtgpu_p2p_get_pages);

int mtgpu_p2p_put_pages(uint64_t virtual_address,
                        struct mtgpu_p2p_page_table *page_table)
{
    return -EINVAL;
}
EXPORT_SYMBOL(mtgpu_p2p_put_pages);

int mtgpu_p2p_dma_map_pages(struct device *dma_device,
                            struct mtgpu_p2p_page_table *page_table,
                            struct mtgpu_dma_mapping **dma_mapping)
{
    return -EINVAL;
}
EXPORT_SYMBOL(mtgpu_p2p_dma_map_pages);

int mtgpu_p2p_dma_unmap_pages(struct device *dma_device,
                              struct mtgpu_dma_mapping *dma_mapping)
{
    return -EINVAL;
}
EXPORT_SYMBOL(mtgpu_p2p_dma_unmap_pages);

void *
ib_register_peer_memory_client(const struct peer_memory_client *peer_client,
                               invalidate_peer_memory *invalidate_callback)
{
    return NULL;
}
EXPORT_SYMBOL(ib_register_peer_memory_client);

void ib_unregister_peer_memory_client(void *reg_handle)
{
    return;
}
EXPORT_SYMBOL(ib_unregister_peer_memory_client);

static int __init mtgpu_p2p_dummy_init(void)
{
    return 0;
}

static void __exit mtgpu_p2p_dummy_cleanup(void)
{
}

module_init(mtgpu_p2p_dummy_init);
module_exit(mtgpu_p2p_dummy_cleanup);
