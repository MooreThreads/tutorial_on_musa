#!/bin/bash
#
# Copyright (c) 2022 Moore Threads Technologies. All rights reserved.
#
SCRIPTPATH=$(cd `dirname "${BASH_SOURCE[0]}"` && pwd)

MOD_SYMVERS=${SCRIPTPATH}/mt.symvers
KVER=${1:-$(uname -r)}

# Create empty symvers file
echo -n "" > $MOD_SYMVERS

mtgpu_mod=
crc_found=0
crc_mod_str="__crc_mtgpu_p2p_"
modules_pat="$crc_mod_str|T mtgpu_p2p_"
for mod in mtgpu $(find /lib/modules/$KVER -name "mtgpu*.ko*" 2>/dev/null)
do
	mtgpu_mod=$(/sbin/modinfo -F filename -k "$KVER" $mod 2>/dev/null)
	if [ ! -e "$mtgpu_mod" ]; then
		continue
	fi

	if ! (nm -o $mtgpu_mod | grep -q -E "$modules_pat"); then
		continue
	fi

	echo "Getting symbol versions from $mtgpu_mod ..."
	while read -r line
	do
		if echo "$line" | grep -q "$crc_mod_str"; then
			crc_found=1
		else
			if [ "$crc_found" != 0 ]; then
				continue
			fi
		fi
		file=$(echo $line | cut -f1 -d: | sed -r -e 's@\./@@' -e 's@.ko(\S)*@@' -e "s@$PWD/@@")
        crc=$(echo $line | cut -f2 -d: | cut -f1 -d" ")
		sym=$(echo $line | cut -f2 -d: | cut -f3 -d" " | sed -e 's/__crc_//g')
		echo -e "0x$crc\t$sym\t$file\tEXPORT_SYMBOL\t" >> $MOD_SYMVERS
	done < <(nm -o $mtgpu_mod | grep -E "$modules_pat")

	echo "Created: ${MOD_SYMVERS}"
	exit 0
done

if [ ! -e "$mtgpu_mod" ]; then
	echo "-E- Cannot locate mtgpu modules!" >&2
	echo "Moore Threads driver must be installed before installing this package!" >&2
	exit 1
fi

if [ ! -s "$MOD_SYMVERS" ]; then
	echo "-W- Could not get list of mtgpu symbols." >&2
fi
