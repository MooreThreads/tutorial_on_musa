#include <linux/kernel.h>

#include "mt_peermem.h"

inline void peer_info(const char *printf_format, ...)
{
    va_list arglist;

    va_start(arglist, printf_format);
    vprintk(printf_format, arglist);
    va_end(arglist);
}

void peer_debug(const char *printf_format, ...)
{
#ifdef DEBUG
    va_list arglist;

    va_start(arglist, printf_format);
    vprintk(printf_format, arglist);
    va_end(arglist);
#endif
}

inline void peer_err(const char *printf_format, ...)
{
    va_list arglist;

    va_start(arglist, printf_format);
    vprintk(printf_format, arglist);
    va_end(arglist);
}