# mt_peermem

## Pre require

* Make sure `mtgpu.ko` is installed
* Make sure `infiniband` is installed

## Build the binary

* with root permission to build the binary
```
# cd mt_peermem
# make
```
