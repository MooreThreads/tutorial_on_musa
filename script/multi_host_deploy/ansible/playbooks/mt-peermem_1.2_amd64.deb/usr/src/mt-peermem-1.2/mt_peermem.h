/*
 * Copyright (c) 2023 Moore Threads Technologies. All rights reserved.
 */

#pragma once
#ifndef _MT_PEERMEM_H_
#define _MT_PEERMEM_H_

#define DRV_NAME "mt_peermem"
#define DRV_VERSION MTGPU_VERSION_STRING

void peer_info(const char *printf_format, ...);
void peer_debug(const char *printf_format, ...);
void peer_err(const char *printf_format, ...);

#endif
