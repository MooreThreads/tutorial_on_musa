/*
 * Copyright © 2022-2024 Moore Threads Inc. All rights reserved.
 *
 */

#include <linux/mm.h>
#include <linux/dma-mapping.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/hugetlb.h>
#include <linux/pci.h>

#include "mt_peermem.h"
#include "mt-p2p.h"
#include "ib_peer_mem.h"
#include "version.h"

MODULE_AUTHOR("Moore Threads GPU Cloud Computing");
MODULE_DESCRIPTION("Moore Threads GPU direct memory plug-in");
MODULE_LICENSE("Dual MIT/GPL");
MODULE_VERSION(DRV_VERSION);

static void *reg_handle = NULL;
struct mtgpu_mem_context
{
    struct mtgpu_p2p_page_table *page_table;
    struct mtgpu_dma_mapping *dma_mapping;
    uint64_t core_context;
    uint64_t page_virt_start;
    uint64_t page_virt_end;
    size_t mapped_size;
    unsigned long npages;
    unsigned long page_size;
    int sg_allocated;
    struct sg_table sg_head;
};

/*
 * acquire return code:
 *  1: mine
 *  0: not mine
 */
static int mtgpu_mem_acquire(unsigned long addr, size_t size, void *peer_mem_private_data,
                             char *peer_mem_name, void **client_context)
{
    int ret = 0;
    struct mtgpu_mem_context *mtgpu_mem_context;

    peer_debug("[%s:%d] acquire with addr:0x%lx and size:0x%lx\n", __FUNCTION__, __LINE__, addr, size);

    mtgpu_mem_context = kzalloc(sizeof *mtgpu_mem_context, GFP_KERNEL);
    if (!mtgpu_mem_context)
    {
        peer_err("[%s:%d] failed to alloc memory\n", __FUNCTION__, __LINE__);
        /* Error case handled as not mine */
        return 0;
    }

    ret = mtgpu_p2p_get_pages(addr, size, &mtgpu_mem_context->page_table);
    if (ret < 0)
    {
        peer_err("[%s:%d] call mtgpu_p2p_get_pages with page_virt_start:0x%llx and size:0x%lx failed: %d\n",
                 __FUNCTION__, __LINE__,
                 mtgpu_mem_context->page_virt_start,
                 mtgpu_mem_context->mapped_size,
                 ret);
        goto err;
    }
    if (mtgpu_mem_context->page_table->version != MTGPU_P2P_PAGE_TABLE_VERSION)
    {
        peer_err("[%s:%d] call mtgpu_p2p_get_pages failed: version mismatched\n",
                 __FUNCTION__, __LINE__);
        goto err;
    }
    if (mtgpu_mem_context->page_table != NULL)
        mtgpu_mem_context->page_size = mtgpu_mem_context->page_table->page_size;

    ret = mtgpu_p2p_put_pages(mtgpu_mem_context->page_virt_start, mtgpu_mem_context->page_table);
    if (ret < 0)
    {
        /* Not expected, however in case callback was called on that buffer just before
            put pages we'll expect to fail gracefully (confirmed by mtgpu) and return an error.
        */
        peer_err("[%s:%d] call mtgpu_p2p_put_pages with page_virt_start:0x%llx and size:0x%lx failed: %d\n",
                 __FUNCTION__, __LINE__,
                 mtgpu_mem_context->page_virt_start,
                 mtgpu_mem_context->mapped_size,
                 ret);
        goto err;
    }

    /* 1 means mine */
    *client_context = mtgpu_mem_context;
    __module_get(THIS_MODULE);
    peer_debug("[%s:%d] mine pages in acquire\n", __FUNCTION__, __LINE__);
    return 1;

err:
    kfree(mtgpu_mem_context);

    /* Error case handled as not mine */
    peer_debug("[%s:%d] not mine pages in acquire\n", __FUNCTION__, __LINE__);
    return 0;
}

static int mtgpu_dma_map(struct sg_table *sg_head, void *context,
                         struct device *dma_device, int dmasync,
                         int *nmap)
{
    int i, ret, npages;
    struct scatterlist *sg;
    struct mtgpu_mem_context *mtgpu_mem_context = (struct mtgpu_mem_context *)context;
    struct mtgpu_p2p_page_table *page_table = mtgpu_mem_context->page_table;
    struct mtgpu_dma_mapping *dma_mapping = NULL;

    if (!dma_device)
    {
        peer_err("[%s:%d] invalid pci_dev, dma_device == nil\n", __FUNCTION__, __LINE__);
        return -EINVAL;
    }

    peer_debug("[%s:%d] ready to call mtgpu_p2p_dma_map_pages\n",
               __FUNCTION__, __LINE__);
    ret = mtgpu_p2p_dma_map_pages(dma_device, page_table, &dma_mapping);
    if (ret)
    {
        peer_err("[%s:%d] failed with error:%d while calling mtgpu_p2p_dma_map_pages()\n",
                 __FUNCTION__, __LINE__, ret);
        return ret;
    }

    if (!dma_mapping)
    {
        peer_debug("[%s:%d] call mtgpu_p2p_dma_map_pages, dma_mapping == NULL\n", __FUNCTION__, __LINE__);
        npages = page_table->array_count;
    } else
    {
        if (dma_mapping->version != MTGPU_P2P_DMA_MAPPING_VERSION)
        {
            peer_err("[%s:%d] call mtgpu_p2p_dma_map_pages failed: version mismatched\n",
                     __FUNCTION__, __LINE__);
            return -EINVAL;
        }
        npages = dma_mapping->array_count;
    }

    mtgpu_mem_context->npages = npages;

    ret = sg_alloc_table(sg_head, npages, GFP_KERNEL);
    if (ret)
    {
        mtgpu_p2p_dma_unmap_pages(dma_device, dma_mapping);
        return ret;
    }

    mtgpu_mem_context->dma_mapping = dma_mapping;
    mtgpu_mem_context->sg_allocated = 1;
    for_each_sg(sg_head->sgl, sg, mtgpu_mem_context->npages, i)
    {
        sg_set_page(sg, NULL, mtgpu_mem_context->page_size, 0);
        if (dma_mapping)
        {
            sg->dma_address = dma_mapping->dma_address_array[i];
            sg->dma_length = dma_mapping->dma_length_array[i];
        } else
        {
            sg->dma_address = page_table->cpu_pa_array[i];
            sg->dma_length = page_table->page_size;
        }
    }
    mtgpu_mem_context->sg_head = *sg_head;
    *nmap = mtgpu_mem_context->npages;

    return 0;
}

static int mtgpu_dma_unmap(struct sg_table *sg_head, void *context,
                           struct device *dma_device)
{
    struct mtgpu_mem_context *mtgpu_mem_context = (struct mtgpu_mem_context *)context;

    if (!mtgpu_mem_context)
    {
        peer_err("[%s:%d] invalid mtgpu_mem_context\n", __FUNCTION__, __LINE__);
        return -EINVAL;
    }

    if (WARN_ON(0 != memcmp(sg_head, &mtgpu_mem_context->sg_head, sizeof(*sg_head))))
        return -EINVAL;

    if (mtgpu_mem_context->dma_mapping)
        mtgpu_p2p_dma_unmap_pages(dma_device, mtgpu_mem_context->dma_mapping);

    return 0;
}

static void mtgpu_mem_put_pages(struct sg_table *sg_head, void *context)
{
    int ret = 0;
    struct mtgpu_mem_context *mtgpu_mem_context = (struct mtgpu_mem_context *)context;

    if (!mtgpu_mem_context)
    {
        peer_err("[%s:%d] invalid mtgpu_mem_context\n", __FUNCTION__, __LINE__);
        return;
    }

    if (WARN_ON(0 != memcmp(sg_head, &mtgpu_mem_context->sg_head, sizeof(*sg_head))))
        return;

    ret = mtgpu_p2p_put_pages(mtgpu_mem_context->page_virt_start, mtgpu_mem_context->page_table);
    if (ret < 0)
    {
        peer_err("[%s:%d] error %d while calling mtgpu_p2p_put_pages, page_table=%p\n",
                 __FUNCTION__, __LINE__,
                 ret, mtgpu_mem_context->page_table);
    }

    return;
}

static void mtgpu_mem_release(void *context)
{
    struct mtgpu_mem_context *mtgpu_mem_context =
        (struct mtgpu_mem_context *)context;
    if (mtgpu_mem_context->sg_allocated)
    {
        sg_free_table(&mtgpu_mem_context->sg_head);
        mtgpu_mem_context->sg_allocated = 0;
    }
    kfree(mtgpu_mem_context);
    module_put(THIS_MODULE);
    return;
}

static int mtgpu_mem_get_pages(unsigned long addr,
                               size_t size, int write, int force,
                               struct sg_table *sg_head,
                               void *client_context,
                               u64 core_context)
{
    int ret;
    struct mtgpu_mem_context *mtgpu_mem_context = (struct mtgpu_mem_context *)client_context;
    if (!mtgpu_mem_context)
    {
        peer_err("[%s:%d] invalid mtgpu_mem_context\n", __FUNCTION__, __LINE__);
        return -EINVAL;
    }
    uint64_t page_size = mtgpu_mem_context->page_table->page_size;
    uint64_t page_mask = ~(page_size - 1);

    mtgpu_mem_context->core_context = core_context;
    mtgpu_mem_context->page_virt_start = addr & page_mask;
    mtgpu_mem_context->page_virt_end = (addr + size + page_size - 1) & page_mask;
    mtgpu_mem_context->mapped_size = mtgpu_mem_context->page_virt_end - mtgpu_mem_context->page_virt_start;

    peer_debug("[%s:%d] ready to call mtgpu_p2p_get_pages with virt_start=%p and size=%d\n",
               __FUNCTION__, __LINE__,
               mtgpu_mem_context->page_virt_start,
               mtgpu_mem_context->mapped_size);

    ret = mtgpu_p2p_get_pages(mtgpu_mem_context->page_virt_start, mtgpu_mem_context->mapped_size,
                              &mtgpu_mem_context->page_table);
    if (ret < 0)
    {
        peer_err("[%s:%d] error %d while calling mtgpu_p2p_get_pages(0x%llx, 0x%lx, %p)\n",
                 __FUNCTION__, __LINE__, ret,
                 mtgpu_mem_context->page_virt_start,
                 mtgpu_mem_context->mapped_size,
                 mtgpu_mem_context->page_table);
        return ret;
    }

    /* No extra access to mtgpu_mem_context->page_table here as we are
        called not under a lock and may race with inflight invalidate callback on that buffer.
        Extra handling was delayed to be done under mtgpu_dma_map.
     */
    peer_debug("[%s:%d] success to call mtgpu_p2p_get_pages with virt_start=%p and size=0x%lx, ret=%d\n",
               __FUNCTION__, __LINE__,
               mtgpu_mem_context->page_virt_start,
               mtgpu_mem_context->mapped_size,
               ret);
    return 0;
}

static unsigned long mtgpu_mem_get_page_size(void *context)
{
    struct mtgpu_mem_context *mtgpu_mem_context =
        (struct mtgpu_mem_context *)context;

    return mtgpu_mem_context->page_size;
}

static struct peer_memory_client mtgpu_mem_client = {
    .acquire = mtgpu_mem_acquire,
    .get_pages = mtgpu_mem_get_pages,
    .dma_map = mtgpu_dma_map,
    .dma_unmap = mtgpu_dma_unmap,
    .put_pages = mtgpu_mem_put_pages,
    .get_page_size = mtgpu_mem_get_page_size,
    .release = mtgpu_mem_release,
    .get_context_private_data = NULL,
    .put_context_private_data = NULL,
};

static int mtgpu_mem_param_conf_check(void)
{
    return 0;
}

static int __init mtgpu_mem_client_init(void)
{
    int ret;
    ret = mtgpu_mem_param_conf_check();
    if (ret)
    {
        peer_err("mem param conf check failed: %d\n", ret);
        return ret;
    }
    // off by one, to leave space for the trailing '1' which is flagging
    // the new client type
    BUG_ON(strlen(DRV_NAME) > IB_PEER_MEMORY_NAME_MAX - 1);
    strcpy(mtgpu_mem_client.name, DRV_NAME);

    // [VER_MAX-1]=1 <-- last byte is used as flag
    // [VER_MAX-2]=0 <-- version string terminator
    BUG_ON(strlen(DRV_VERSION) > IB_PEER_MEMORY_VER_MAX - 2);
    strcpy(mtgpu_mem_client.version, DRV_VERSION);

    mtgpu_mem_client.version[IB_PEER_MEMORY_VER_MAX - 1] = 1;

    reg_handle = ib_register_peer_memory_client(&mtgpu_mem_client, NULL);
    if (!reg_handle)
    {
        peer_err("error while registering traditional client\n");
        ret = -EINVAL;
        goto out;
    }
    peer_debug("success to insert module of mt_peermem with version=%s\n",
               MTGPU_VERSION_STRING);
out:
    if (ret)
        if (reg_handle)
        {
            ib_unregister_peer_memory_client(reg_handle);
            reg_handle = NULL;
        }

    return ret;
}

static void __exit mtgpu_mem_client_cleanup(void)
{
    if (reg_handle)
        ib_unregister_peer_memory_client(reg_handle);
}

module_init(mtgpu_mem_client_init);
module_exit(mtgpu_mem_client_cleanup);
